# LINCS Commercial Cleaning Services - Official Website

A high-performance, modern commercial cleaning website built with React, Vite, TypeScript, and Tailwind CSS.

## 🚀 Quick Start (Development)

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the local development server**:
   ```bash
   npm run dev
   ```
   Open your browser at `http://localhost:3000` or the port shown in your terminal.

3. **Build for production**:
   ```bash
   npm run build
   ```
   The compiled static files will be generated in the `dist/` directory.

## 📦 Deploying the Website

You can deploy the files inside the `dist/` folder to any web hosting platform:
- **Netlify**: Drag & drop the `dist/` folder to netlify.com/drop
- **Vercel**: Run `npx vercel` or link this repository
- **cPanel / Apache / Nginx**: Upload the contents of `dist/` into `public_html/`
- **GitHub Pages**: Deploy the `dist/` branch or static export

## 🛠 Tech Stack
- **Framework**: React 18+ / Vite
- **Styling**: Tailwind CSS v4
- **Language**: TypeScript
- **Icons**: Lucide React
